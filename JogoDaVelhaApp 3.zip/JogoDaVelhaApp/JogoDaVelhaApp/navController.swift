//
//  navController.swift
//  JogoDaVelhaApp
//
//  Created by pos on 30/11/2018.
//  Copyright © 2018 pos. All rights reserved.
//

import UIKit

class navController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()


        // Seta as cores do NavBar
        self.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
        self.navigationBar.tintColor = .white
        self.navigationBar.barTintColor = color
        self.navigationBar.isTranslucent = false
    }
    
    // Seta a cor do StatusBar 
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return UIStatusBarStyle.lightContent
    }
}
