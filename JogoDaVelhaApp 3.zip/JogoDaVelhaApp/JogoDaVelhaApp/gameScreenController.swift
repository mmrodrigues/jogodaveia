//
//  gameScreenController.swift
//  JogoDaVelhaApp
//
//  Created by pos on 30/11/2018.
//  Copyright © 2018 pos. All rights reserved.
//

import UIKit

class gameScreenController: UIViewController, UITextFieldDelegate {
    
    var jogadorAtual = 1
    var jogoAtivo = true
    var estadoJogo = [0, 0, 0, 0, 0, 0, 0, 0, 0]
    var cliquesCount = 0
    var imageButtonPlayer1 = UIImage()
    var imageButtonPlayer2 = UIImage()
    
    // Possíveis combinações para vencer o jogo
    let correctCombinations = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]]
    
    // Array com as imagens
    let arrayOfImages : NSArray = [UIImage(named: "wat.png")!,
                                   UIImage(named: "dercy.png")!]
    
    @IBOutlet weak var btnJogarNovamente: UIButton!
    @IBOutlet weak var lblGameOver: UILabel!
    @IBOutlet weak var lblNomePlayer1: UILabel!
    @IBOutlet weak var lblNomePlayer2: UILabel!
    @IBOutlet weak var lblQuantidadeEmpates: UILabel!
    @IBOutlet weak var lblQuantidadeJogos: UILabel!
    @IBOutlet weak var btnRefresh: UIBarButtonItem!
    @IBOutlet weak var imgStatusPlayer1: UIImageView!
    @IBOutlet weak var imgStatusPlayer2: UIImageView!
    @IBOutlet weak var lblPontosPlayer1: UILabel!
    @IBOutlet weak var lblPontosPlayer2: UILabel!
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var partPlayer1: UIImageView!
    @IBOutlet weak var partPlayer2: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Limpa o texto do botão voltar
        let backItem = UIBarButtonItem()
        backItem.title = ""
        navigationItem.backBarButtonItem = backItem
        
        // Arredonda os cantos do botão salvar
        btnJogarNovamente.layer.cornerRadius = btnJogarNovamente.bounds.width / 12
        lblGameOver.layer.masksToBounds = true
        lblGameOver.layer.cornerRadius = 5
    }
    
    func getGames() {
        
        // Se existir os nomes no UserDefaults configurados na tela de configuração:
        if (UserDefaults.standard.value(forKey: "nomePlayer1") != nil) &&
            (UserDefaults.standard.value(forKey: "nomePlayer2") != nil) &&
            (UserDefaults.standard.value(forKey: "pontosPlayer1") != nil) &&
            (UserDefaults.standard.value(forKey: "pontosPlayer2") != nil) &&
            (UserDefaults.standard.value(forKey: "quantidadeJogosTerminados") != nil) &&
            (UserDefaults.standard.value(forKey: "quantidadeEmpates") != nil) {
            
            // Carrega os dados
            nomePlayer1 = UserDefaults.standard.value(forKey: "nomePlayer1") as! String
            nomePlayer2 = UserDefaults.standard.value(forKey: "nomePlayer2") as! String
            pontosPlayer1 = UserDefaults.standard.value(forKey: "pontosPlayer1") as! Int
            pontosPlayer2 = UserDefaults.standard.value(forKey: "pontosPlayer2") as! Int
            quantidadeJogosTerminados = UserDefaults.standard.value(forKey: "quantidadeJogosTerminados") as! Int
            quantidadeEmpates = UserDefaults.standard.value(forKey: "quantidadeEmpates") as! Int
        } // Sem usuarios configurados
        else {
            // Define os valores inciais nas variaveis globais
            nomePlayer1 = "Jogador 1"
            nomePlayer2 = "Jogador 2"
            pontosPlayer1 = 0
            pontosPlayer2 = 0
            quantidadeJogosTerminados = 0
            quantidadeEmpates = 0
            
            // salva os dados no UserDefaults
            UserDefaults.standard.set(nomePlayer1, forKey: "nomePlayer1")
            UserDefaults.standard.set(nomePlayer2, forKey: "nomePlayer2")
            UserDefaults.standard.set(pontosPlayer1, forKey: "pontosPlayer1")
            UserDefaults.standard.set(pontosPlayer2, forKey: "pontosPlayer2")
            UserDefaults.standard.set(quantidadeJogosTerminados, forKey: "quantidadeJogosTerminados")
            UserDefaults.standard.set(quantidadeEmpates, forKey: "quantidadeEmpates")
        }
        
        
        // mostra os dados na UI
        lblNomePlayer1.text = nomePlayer1
        lblNomePlayer2.text = nomePlayer2
        lblPontosPlayer1.text = "\(pontosPlayer1)"
        lblPontosPlayer2.text = "\(pontosPlayer2)"
        lblQuantidadeJogos.text = "\(quantidadeJogosTerminados)"
        lblQuantidadeEmpates.text = "\(quantidadeEmpates)"

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        getGames()
        
        btnJogarNovamente.isHidden = true
        lblGameOver.isHidden = true
        
        imgStatusPlayer1.image = UIImage(named: "active.png")
        imgStatusPlayer2.image = UIImage(named: "disactivate.png")
        
        // Inicia o jogo novamente
        jogarNovamente()
        
        //gerarLayout()
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    @IBAction func buttonPressed(_ sender: UIButton) {
        // se a posição atual tiver a tag 0, e existe um jogo ativo
        if estadoJogo[sender.tag] == 0 && jogoAtivo == true {
            
            var image = UIImage()
            
            // adiciona mais um clique ao contador
            cliquesCount += 1
            
            estadoJogo[sender.tag] = jogadorAtual
            
            // player 1 está ativo
            if jogadorAtual == 1 {
                
                image = imageButtonPlayer1
                
                // troca para o player 2
                jogadorAtual = 2
                imgStatusPlayer2.image = UIImage(named: "active.png")
                
                // desativa o player 1
                imgStatusPlayer1.image = UIImage(named: "disactivate.png")
            }
                // player 2 está ativo
            else {
                
                // coloca a imagem na posição atual
                image = imageButtonPlayer2
                
                // ativa o player 1
                jogadorAtual = 1
                imgStatusPlayer1.image = UIImage(named: "active.png")
                
                // desativa o player 2
                imgStatusPlayer2.image = UIImage(named: "disactivate.png")
            }
            sender.setImage(image, for: UIControlState())
            
            // se for uma combinação correta
            for combination in correctCombinations {
                if estadoJogo[combination[0]] != 0 && estadoJogo[combination[0]] == estadoJogo[combination[1]] && estadoJogo[combination[1]] == estadoJogo[combination[2]] {
                    
                    var winnerText = "\(nomePlayer1) venceu! 😛"
                    
                    // se o vencedor for o player 2
                    if estadoJogo[combination[0]] == 2 {
                        winnerText = "\(nomePlayer2) venceu! 😜"
                        
                        // limpa a contagem dos cliques
                        cliquesCount = 0
                        
                        // adiciona um ponto ao player 2
                        pontosPlayer2 += 1
                        UserDefaults.standard.set(pontosPlayer2, forKey: "pontosPlayer2")
                        lblPontosPlayer2.text = "\(pontosPlayer2)"
                        
                    } else {
                        
                        // adiciona um ponto ao player 1
                        pontosPlayer1 += 1
                        UserDefaults.standard.set(pontosPlayer1, forKey: "pontosPlayer1")
                        lblPontosPlayer1.text = "\(pontosPlayer2)"
                    }
                    
                    //desabilita o botão refresh
                    self.btnRefresh.isEnabled = false
                    
                    imgStatusPlayer1.image = UIImage(named: "active.png")
                    imgStatusPlayer2.image = UIImage(named: "disactivate.png")
                    
                    lblGameOver.text = winnerText
                    
                    // seta como nenhum jogo ativo
                    jogoAtivo = false
                    
                    // limpa o total de cliques
                    cliquesCount = 0
                    
                    // mais um pro total de jogos terminados
                    quantidadeJogosTerminados += 1
                    UserDefaults.standard.set(quantidadeJogosTerminados, forKey: "quantidadeJogosTerminados")
                    lblQuantidadeJogos.text = "\(quantidadeJogosTerminados)"
                    
                    // mostra o botão e a label que sobrepõe a tela
                    lblGameOver.isHidden = false
                    btnJogarNovamente.isHidden = false
                    
                    // animações para os botões
                    UIView.animate(withDuration: 0.5, animations: { () -> Void in
                        
                        self.lblGameOver.center = CGPoint(x: self.lblGameOver.center.x + 1000, y: self.lblGameOver.center.y)
                        self.btnJogarNovamente.center = CGPoint(x: self.btnJogarNovamente.center.x + 1000, y: self.btnJogarNovamente.center.y)
                        
                    }) {(finished:Bool) in
                        
                        if finished {
                            
                            UIView.animate(withDuration: 0.5, delay: 3, animations: {
                                
                                self.lblGameOver.center = CGPoint(x: self.lblGameOver.center.x + 1000, y: self.lblGameOver.center.y)
                            })
                        }
                    }
                }
            }
            // sem vencedor
            if cliquesCount == 9 && jogoAtivo {
                
                self.btnRefresh.isEnabled = false
                
                imgStatusPlayer1.image = UIImage(named: "active.png")
                imgStatusPlayer2.image = UIImage(named: "disactivate.png")
                
                // limpa o total de cliques
                cliquesCount = 0
                
                // desativa o jogo atual
                jogoAtivo = false
                
                // mostra a label e o botão
                lblGameOver.isHidden = false
                btnJogarNovamente.isHidden = false
                
                lblGameOver.text = "Sem vencedor.\nJogue novamente!"
                
                // +1 pra quantidade de empates
                quantidadeEmpates += 1
                UserDefaults.standard.set(quantidadeEmpates, forKey: "quantidadeEmpates")
                lblQuantidadeEmpates.text = "\(quantidadeEmpates)"
                
                // +1 pra quantidade de jogos encerrados
                quantidadeJogosTerminados += 1
                UserDefaults.standard.set(quantidadeJogosTerminados, forKey: "quantidadeJogosTerminados")
                lblQuantidadeJogos.text = "\(quantidadeJogosTerminados)"
                
                // inicia animação na label e botão que sobrepõe a tela
                UIView.animate(withDuration: 0.5, animations: { () -> Void in
                    
                    self.lblGameOver.center = CGPoint(x: self.lblGameOver.center.x + 1000, y: self.lblGameOver.center.y)
                    self.btnJogarNovamente.center = CGPoint(x: self.btnJogarNovamente.center.x + 1000, y: self.btnJogarNovamente.center.y)
                    
                }) { (finished:Bool) in
                    
                    if finished {
                        
                        UIView.animate(withDuration: 0.5, delay: 3, animations: {
                            
                            self.lblGameOver.center = CGPoint(x: self.lblGameOver.center.x + 1000, y: self.lblGameOver.center.y)
                        })
                    }
                }
            }
        }
    }
    @IBAction func refreshBtnPressed(_ sender: UIBarButtonItem) {
        // Cria o alerta para verificar se deve terminar
        let alert = UIAlertController(title: "Terminar?", message: "Deseja encerrar o jogo atual?", preferredStyle: .alert)
        
        // Adiciona a action SIM e define o botão no alert
        alert.addAction(UIAlertAction(title: "SIM", style: .default, handler: { (action) -> Void in
            
            // Joga novamente
            self.jogarNovamente()
        }))
        
        alert.addAction(UIAlertAction(title: "NÃO", style: .cancel, handler: {(action) -> Void in }))
        
        // Mostra o alert na view
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func novoJogo(_ sender: UIButton) {
        
        // Joga novamente
        jogarNovamente()
    }
    
    // Função para iniciar o jogo novamente
    func jogarNovamente() {
        
        btnRefresh.isEnabled = true
        
        // chama a função para gerar o layout
        gerarLayout()
        
        // ativa o player1
        jogadorAtual = 1
        imgStatusPlayer1.image = UIImage(named: "active.png")
        imgStatusPlayer2.image = UIImage(named: "disactivate.png")
        // define que existe um jogo rolando
        jogoAtivo = true
        
        // array pra salvar a posição de cada jogada
        estadoJogo = [0, 0, 0, 0, 0, 0, 0, 0, 0]
        
        // opções que o usuário tem pra selecionar
        var btn: UIButton
        for i in 0 ..< 9 {
            let newView = view.viewWithTag(i)
            if(newView is UIButton){
                btn = newView as! UIButton
                btn.setImage(nil, for: UIControlState())
            }
        }
        
        // esconde as labels de game over e botão jogar novamente
        lblGameOver.isHidden = true
        btnJogarNovamente.isHidden = true
        
        // joga os botões 500px pra esquerda
        lblGameOver.center = CGPoint(x: lblGameOver.center.x - 1000, y: lblGameOver.center.y)
        btnJogarNovamente.center = CGPoint(x: btnJogarNovamente.center.x - 1000, y: btnJogarNovamente.center.y)
    }
    
    func gerarLayout() {
        
        // escolhe imagem 1
        let imagerange: UInt32 = UInt32(arrayOfImages.count)
        let randomimage = Int(arc4random_uniform(imagerange))
        let generatedimage: AnyObject = arrayOfImages.object(at: randomimage) as AnyObject
        
        // escolhe imagem 2
        let imagerange2: UInt32 = UInt32(arrayOfImages.count)
        let randomimage2 = Int(arc4random_uniform(imagerange2))
        let generatedimage2: AnyObject = arrayOfImages.object(at: randomimage2) as AnyObject
        
        // se imagens forem iguais, gera novamente
        if (generatedimage as? UIImage)! == (generatedimage2 as? UIImage)! {
            gerarLayout()
        }
            // se não forem iguais, seta imagem dos players
        else {
            imageButtonPlayer1 = (generatedimage as? UIImage)!
            imageButtonPlayer2 = (generatedimage2 as? UIImage)!
            partPlayer1.image = (generatedimage as? UIImage)!
            partPlayer2.image = (generatedimage2 as? UIImage)!
        }
    }
    
}
