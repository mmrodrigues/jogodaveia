//
//  configController.swift
//  JogoDaVelhaApp
//
//  Created by pos on 30/11/2018.
//  Copyright © 2018 pos. All rights reserved.
//

import UIKit

class configController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtPlayer1: UITextField!
    @IBOutlet weak var txtPlayer2: UITextField!
    @IBOutlet weak var btnSalvar: UIButton!
    @IBOutlet weak var lblPlayer1: UILabel!
    @IBOutlet weak var lblPlayer2: UILabel!
    @IBOutlet weak var lblPontosPlayer1: UILabel!
    @IBOutlet weak var lblPontosPlayer2: UILabel!
    @IBOutlet weak var lblEmpates: UILabel!
    @IBOutlet weak var lblTotalJogos: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Limpa o texto do botão voltar
        let backItem = UIBarButtonItem()
        backItem.title = ""
        navigationItem.backBarButtonItem = backItem
        
        // Arredonda os cantos do botão salvar
        btnSalvar.layer.cornerRadius = btnSalvar.bounds.width / 9
        
        // Inativa o botão salvar
        btnSalvar.isEnabled = false
        btnSalvar.alpha = 0.3
        
        // Coloca o delegate nos textFields
        txtPlayer1.delegate = self
        txtPlayer2.delegate = self
        
        txtPlayer1.text! = nomePlayer1
        txtPlayer2.text! = nomePlayer2
        lblPlayer1.text = nomePlayer1
        lblPlayer2.text = nomePlayer2
        lblPontosPlayer1.text = "\(pontosPlayer1)"
        lblPontosPlayer2.text = "\(pontosPlayer2)"
        lblTotalJogos.text = "\(quantidadeJogosTerminados)"
        lblEmpates.text = "\(quantidadeEmpates)"
        
        // Adiciona o target para execução dos métodos nos textFields
        txtPlayer1.addTarget(self, action: #selector(configController.textFieldDidChange(_:)), for: .editingChanged)
        txtPlayer2.addTarget(self, action: #selector(configController.textFieldDidChange(_:)), for: .editingChanged)
    }
    
    // Quando algum texto muda nos textFields
    @objc func textFieldDidChange(_ textField : UITextView) {
        
        // Se for em branco, inativa o botão salvar
        if txtPlayer1.text!.isEmpty || txtPlayer2.text!.isEmpty &&
            txtPlayer1.text!.count < 3 && txtPlayer2.text!.count < 3 {
            
            btnSalvar.isEnabled = false
            btnSalvar.alpha = 0.3
            
        }// Se tiver algum caracter - ativa o botão salvar
        else {
            btnSalvar.isEnabled = true
            btnSalvar.alpha = 1
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose nos objetos
    }

    @IBAction func btnSalvarClick(_ sender: UIButton) {
        self.view.endEditing(false)
        
        // limpa os nomes atuais
        nomePlayer1.removeAll()
        nomePlayer2.removeAll()
        
        // da append nos nomes atuais com os valores dos txt
        nomePlayer1.append(txtPlayer1.text!)
        nomePlayer2.append(txtPlayer2.text!)
        
        // seta os keyValues no UserDefaults
        UserDefaults.standard.set(nomePlayer1, forKey: "nomePlayer1")
        UserDefaults.standard.set(nomePlayer2, forKey: "nomePlayer2")
        
        // seta os textFields
        lblPlayer1.text = nomePlayer1
        lblPlayer2.text = nomePlayer2
        
    }
    @IBAction func btnRedefinir(_ sender: UIButton) {
        // limpa as variáveis globais
        pontosPlayer1 = 0
        pontosPlayer2 = 0
        quantidadeJogosTerminados = 0
        quantidadeEmpates = 0
        
        //limpa os keyValues no UserDefaults
        UserDefaults.standard.set(pontosPlayer1, forKey: "pontosPlayer1")
        UserDefaults.standard.set(pontosPlayer2, forKey: "pontosPlayer2")
        UserDefaults.standard.set(quantidadeJogosTerminados, forKey: "quantidadeJogosTerminados")
        UserDefaults.standard.set(quantidadeEmpates, forKey: "quantidadeEmpates")
        
        // limpa os textFields e Labels
        lblPontosPlayer1.text = "\(pontosPlayer1)"
        lblPontosPlayer2.text = "\(pontosPlayer2)"
        lblTotalJogos.text = "\(quantidadeJogosTerminados)"
        lblEmpates.text = "\(quantidadeEmpates)"
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        // fecha o teclado ao clicar fora do textField
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // fecha o KeyBoard caso o usuário clique no botão voltar
        txtPlayer1.resignFirstResponder()
        txtPlayer2.resignFirstResponder()
        return true
    }
    
}
